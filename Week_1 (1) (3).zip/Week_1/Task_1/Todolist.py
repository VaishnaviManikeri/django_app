# Python Program for a Simple To-Do List
# In this program, the user can manage a to-do list by adding, removing, and viewing tasks.  
# The user selects an option from the menu, performs the desired action, and the updated task list is displayed accordingly.


task_lst = []  # List to store tasks

def add_task():
    enter_task = input("Enter task: ").strip()  # Remove  spaces
    if enter_task:  # Avoid adding empty tasks
        task_lst.append(enter_task)
        print(f"Task '{enter_task}' added successfully!")
    else:
        print("Task cannot be empty!")

def remove_task():
    rem_task = input("Enter task to remove: ").strip()
    if rem_task in task_lst:
        task_lst.remove(rem_task)
        print(f"Task '{rem_task}' removed successfully!")
    else:
        print("Task doesn't exist in the list.")

def view_task():
    if task_lst:
        print("\nYour To-Do List:")
        for i, task in enumerate(task_lst, 1):
            print(f"{i}. {task}")
    else:
        print("\nYour to-do list is empty!")

while True:
    print("\n====== To-Do List Menu ======")
    print("1. Add Task")
    print("2. Remove Task")
    print("3. View Tasks")
    print("4. Exit")

    try:
        ch = int(input("Enter your Choice: "))
        if ch == 1:
            add_task()
        elif ch == 2:
            remove_task()
        elif ch == 3:
            view_task()
        elif ch == 4:
            print("Exiting To-Do List... Goodbye!")
            break
        else:
            print("Invalid Choice, Try again!")
    except ValueError:
        print("Please enter a valid number!")
