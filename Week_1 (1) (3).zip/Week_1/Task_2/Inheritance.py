#Implement a Python class demonstrating OOP principles (Inheritance).
#Inheritance
# allows one class (Child) to reuse the prop and methods of another class(parent).

# Parent Class
class Student:  # Student Class
    def __init__(self,name,grade,percentage):
        self.name = name #attribute
        self.grade = grade
        self.percentage = percentage

    def student_details(self):
        print(f"{self.name} is in class {self.grade}, with {self.percentage}%")


# Object - instance of class
student1 = Student('Madhav', 11, 96)
student2 = Student('Vishakha', 12, 89)

# Child Class

class GraduateStudent(Student): #Graduatestudent child class inherit prop and methods from Student Parent class
    def __init__(self, name, grade, percentage, stream): # old parameters from parent class and new parameters in child class
        super().__init__(name, grade, percentage, ) # call parent class init
        self.stream = stream  # new attribute in child class
    
    def student_details(self):
        super().student_details() # method inherit from parent class
        print(f'Stream is {self.stream}')


# object
Grad_Student1 = GraduateStudent('Keshav', 12, 96, 'PCM')
# print(Grad_Student1.stream) 

Grad_Student1.student_details()