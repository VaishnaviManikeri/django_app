#Implement a Python class demonstrating OOP principles (Polymorphism).
# Polymorphism
# allows methods in difft classes to have same name but difft behaviour depending on objects 

class Student: # student class
    def __init__(self, name, grade, percentage): 
        self.name = name  # attribute 
        self.grade = grade  
        self.percentage = percentage 

    def student_details(self): # method 
        print(f"{self.name} is in class {self.grade}, with {self.percentage}%")

# object - instance of class 
student1 = Student('Madhav', 11, 96)
student2 = Student('Vishakha', 12, 99)

# child class  
class GraduateStudent(Student): 
    def __init__(self, name, grade, percentage, stream): 
        super().__init__(name, grade, percentage) 
        self.stream = stream 

    def student_details(self): # method
        # print(f'{self.name} is in class {self.grade}, with {self.percentage}% and from stream {self.stream}')
        print('same method with difft o/p')

# object - Student class
student1 = Student('Madhav', 11, 96)

# object - GraduateStudent class
Grad_Student1 = GraduateStudent('Keshav', 12, 96, 'PCM')

student1.student_details()
Grad_Student1.student_details()