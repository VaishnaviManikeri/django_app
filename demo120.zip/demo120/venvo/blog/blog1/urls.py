from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='spcl'),  # use views.home instead of views.spcl
]