from django.shortcuts import render

def home(request):
    return render(request, 'blog1/spcl.html')  
# Create your views here.
